1、以下文件用于lab2
        （1）mul_div_test.asm		乘除法测试程序
        （2）mul_div_test.coe		乘除法测试程序（机器码）
        （3）mul_div_simu_behav.wcfg	乘除法功能仿真波形文件

2、以下文件用于lab3：
        （1）start.dump		测试程序
        （2）start.dump.coe		测试程序（机器码）
        （3）soc_simu_behav.wcfg	仿真波形文件